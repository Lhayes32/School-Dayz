from django.apps import AppConfig


class PizzaConfig(AppConfig):
    name = 'pizza'
